import asyncio
import time
from typing import Tuple, List, Dict, Optional

from .global_logger import logger
from .embedding_store import EmbeddingManager
from .kg_manager import KGManager
from .knowledge_base_adapter import KnowledgeBaseAdapter, get_kb_adapter

# from .lpmmconfig import global_config
from .utils.dyn_topk import dyn_select_top_k
from astrbot.core.maibot.chat.utils.utils import get_embedding
from astrbot.core.maibot.config.config import global_config

MAX_KNOWLEDGE_LENGTH = 10000  # 最大知识长度


class QAManager:
    def __init__(
        self,
        embed_manager: EmbeddingManager,
        kg_manager: KGManager,
        kb_adapter: Optional[KnowledgeBaseAdapter] = None,
    ):
        self.embed_manager = embed_manager
        self.kg_manager = kg_manager
        # AstrBot 知识库适配器（可选，用于并行检索）
        self.kb_adapter = kb_adapter

    async def process_query(
        self, question: str
    ) -> Optional[Tuple[List[Tuple[str, float, float]], Optional[Dict[str, float]]]]:
        """处理查询"""

        # 生成问题的Embedding
        part_start_time = time.perf_counter()
        question_embedding = await get_embedding(question)
        if question_embedding is None:
            logger.error("生成问题Embedding失败")
            return None
        part_end_time = time.perf_counter()
        logger.debug(f"Embedding用时：{part_end_time - part_start_time:.5f}s")

        # 根据问题Embedding查询Relation Embedding库
        part_start_time = time.perf_counter()
        relation_search_res = self.embed_manager.relation_embedding_store.search_top_k(
            question_embedding,
            global_config.lpmm_knowledge.qa_relation_search_top_k,
        )
        if relation_search_res is None:
            return None
        # 过滤阈值
        # 考虑动态阈值：当存在显著数值差异的结果时，保留显著结果；否则，保留所有结果
        relation_search_res = dyn_select_top_k(relation_search_res, 0.5, 1.0)
        if not relation_search_res or relation_search_res[0][1] < global_config.lpmm_knowledge.qa_relation_threshold:
            # 未找到相关关系
            logger.debug("未找到相关关系，跳过关系检索")
            relation_search_res = []

        part_end_time = time.perf_counter()
        logger.debug(f"关系检索用时：{part_end_time - part_start_time:.5f}s")

        for res in relation_search_res:
            if store_item := self.embed_manager.relation_embedding_store.store.get(res[0]):
                rel_str = store_item.str
            logger.info(f"找到相关关系，相似度：{(res[1] * 100):.2f}%  -  {rel_str}")

        # TODO: 使用LLM过滤三元组结果
        # logger.info(f"LLM过滤三元组用时：{time.time() - part_start_time:.2f}s")
        # part_start_time = time.time()

        # 根据问题Embedding查询Paragraph Embedding库
        part_start_time = time.perf_counter()
        paragraph_search_res = self.embed_manager.paragraphs_embedding_store.search_top_k(
            question_embedding,
            global_config.lpmm_knowledge.qa_paragraph_search_top_k,
        )
        part_end_time = time.perf_counter()
        logger.debug(f"文段检索用时：{part_end_time - part_start_time:.5f}s")

        if len(relation_search_res) != 0:
            logger.info("找到相关关系，将使用RAG进行检索")
            # 使用KG检索
            part_start_time = time.perf_counter()
            result, ppr_node_weights = self.kg_manager.kg_search(
                relation_search_res, paragraph_search_res, self.embed_manager
            )
            part_end_time = time.perf_counter()
            logger.info(f"RAG检索用时：{part_end_time - part_start_time:.5f}s")
        else:
            logger.info("未找到相关关系，将使用文段检索结果")
            result = paragraph_search_res
            ppr_node_weights = None

        # 过滤阈值
        result = dyn_select_top_k(result, 0.5, 1.0)

        if global_config.debug.show_lpmm_paragraph:
            for res in result:
                raw_paragraph = self.embed_manager.paragraphs_embedding_store.store[res[0]].str
                logger.info(f"找到相关文段，相关系数：{res[1]:.8f}\n{raw_paragraph}\n\n")

        return result, ppr_node_weights

    async def get_knowledge(self, question: str, limit: int = 5) -> Optional[str]:
        """获取知识（支持并行检索 AstrBot 知识库）

        Args:
            question: 查询问题
            limit: 返回的相关知识条数
        """
        # 并行执行：原生检索 + AstrBot 知识库检索
        native_task = asyncio.create_task(self.process_query(question))
        kb_task = asyncio.create_task(self._retrieve_from_astrbot_kb(question))

        # 等待两个任务完成
        native_result, kb_results = await asyncio.gather(
            native_task, kb_task, return_exceptions=True
        )

        # 处理原生检索结果
        native_knowledge = []
        if native_result is not None and not isinstance(native_result, Exception):
            query_res = native_result[0]
            if query_res:
                native_knowledge = [
                    (
                        self.embed_manager.paragraphs_embedding_store.store[res[0]].str,
                        res[1],
                        "maibot",  # 来源标记
                    )
                    for res in query_res
                ]
        elif isinstance(native_result, Exception):
            logger.warning(f"原生检索异常: {native_result}")

        # 处理 AstrBot 知识库检索结果
        kb_knowledge = []
        if kb_results and not isinstance(kb_results, Exception):
            kb_knowledge = [
                (
                    r.content,
                    r.score,
                    f"astrbot:{r.kb_name}",  # 来源标记
                )
                for r in kb_results
            ]
        elif isinstance(kb_results, Exception):
            logger.warning(f"AstrBot 知识库检索异常: {kb_results}")

        # 融合结果（使用 RRF 算法）
        merged_knowledge = self._rrf_fusion(native_knowledge, kb_knowledge)

        if not merged_knowledge:
            if not native_knowledge and not kb_knowledge:
                logger.debug("所有知识库查询结果为空")
                return None
            # 如果融合失败，使用原始结果
            merged_knowledge = native_knowledge + kb_knowledge

        # 限制返回数量
        limit = max(1, limit) if isinstance(limit, int) else 5
        selected_knowledge = merged_knowledge[:limit]

        # 格式化输出
        formatted_knowledge = [
            f"第{i + 1}条知识：{k[0]}\n 该条知识对于问题的相关性：{k[1]:.4f} (来源: {k[2]})"
            for i, k in enumerate(selected_knowledge)
        ]

        found_knowledge = "\n".join(formatted_knowledge)
        if len(found_knowledge) > MAX_KNOWLEDGE_LENGTH:
            found_knowledge = found_knowledge[:MAX_KNOWLEDGE_LENGTH] + "\n"
        return found_knowledge

    async def _retrieve_from_astrbot_kb(self, question: str) -> List:
        """从 AstrBot 知识库检索

        Args:
            question: 查询问题

        Returns:
            检索结果列表
        """
        # 优先使用实例的适配器，否则使用全局适配器
        adapter = self.kb_adapter or get_kb_adapter()
        if adapter is None:
            logger.debug("AstrBot 知识库适配器未配置，跳过检索")
            return []

        try:
            results = await adapter.retrieve(question)
            if results:
                logger.info(f"AstrBot 知识库检索到 {len(results)} 条结果")
            return results
        except Exception as e:
            logger.warning(f"AstrBot 知识库检索失败: {e}")
            return []

    def _rrf_fusion(
        self,
        native_results: List[Tuple[str, float, str]],
        kb_results: List[Tuple[str, float, str]],
        k: int = 60,
    ) -> List[Tuple[str, float, str]]:
        """使用 RRF (Reciprocal Rank Fusion) 算法融合检索结果

        RRF 公式: score = sum(1 / (k + rank_i))

        Args:
            native_results: 原生检索结果 [(content, score, source), ...]
            kb_results: AstrBot 知识库检索结果
            k: RRF 参数，默认 60

        Returns:
            融合后的结果列表，按 RRF 分数降序排列
        """
        if not native_results and not kb_results:
            return []

        # 使用内容作为 key 进行去重和融合
        content_scores: Dict[str, Dict] = {}

        # 处理原生结果
        for rank, (content, score, source) in enumerate(native_results):
            content_key = content[:200]  # 使用前 200 字符作为 key
            if content_key not in content_scores:
                content_scores[content_key] = {
                    "content": content,
                    "rrf_score": 0.0,
                    "source": source,
                    "original_score": score,
                }
            content_scores[content_key]["rrf_score"] += 1.0 / (k + rank + 1)

        # 处理 AstrBot 知识库结果
        for rank, (content, score, source) in enumerate(kb_results):
            content_key = content[:200]
            if content_key not in content_scores:
                content_scores[content_key] = {
                    "content": content,
                    "rrf_score": 0.0,
                    "source": source,
                    "original_score": score,
                }
            else:
                # 如果内容已存在，更新来源为 "merged"
                content_scores[content_key]["source"] = "merged"
            content_scores[content_key]["rrf_score"] += 1.0 / (k + rank + 1)

        # 按 RRF 分数排序
        sorted_results = sorted(
            content_scores.values(),
            key=lambda x: x["rrf_score"],
            reverse=True,
        )

        return [
            (item["content"], item["rrf_score"], item["source"])
            for item in sorted_results
        ]
